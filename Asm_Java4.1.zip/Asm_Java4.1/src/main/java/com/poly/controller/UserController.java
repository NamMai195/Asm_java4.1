package com.poly.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poly.constant.SessionAttr;
import com.poly.entity.User;
import com.poly.service.UserService;
import com.poly.service.impl.UserserviceImpl;
import com.poly.util.StringUtils;

/**
 * Servlet implementation class UserController
 */
@WebServlet({ "/login", "/logout", "/register" })
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserController() {
		super();
		// TODO Auto-generated constructor stub
	}

	private UserService userservice = new UserserviceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getServletPath();
		switch (path) {
		case "/login": {
			doGetLogin(request, response);
			break;
		}
		case "/logout": {
			dogetLogout(request, response);
			break;
		}
		case "/register": {
			doGetRes(request, response);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + path);
		}
	}

	protected void doGetLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher req = request.getRequestDispatcher("views/user/login.jsp");
		req.forward(request, response);
	}

	protected void doGetRes(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher req = request.getRequestDispatcher("views/user/res.jsp");
		req.forward(request, response);
	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String path = request.getServletPath();
		switch (path) {
		case "/login": {
			doPostlogin(session, request, response);
			break;
		}
		case "/register": {
			doPostRes(session, request, response);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + path);
		}
	}

	protected void doPostlogin(HttpSession session, HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		User user = userservice.login(username, password);
		if (user != null) {

			session.setAttribute("currentUser", user);
			response.sendRedirect("index");

		} else {
			System.out.println("Thất Bại");
			response.sendRedirect("login");
		}
	}

	protected void doPostRes(HttpSession session, HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String fullName = request.getParameter("fullName");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String id = request.getParameter("id");
		User user = userservice.findById(id);
		if (user == null) {
			userservice.create(id, fullName, password, email);
		} else {
			System.out.println("Thất Bại");
			response.sendRedirect("register");
		}

	}

	protected void dogetLogout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.removeAttribute(SessionAttr.CURRENT_USER);
		response.sendRedirect("index");
	}

}
