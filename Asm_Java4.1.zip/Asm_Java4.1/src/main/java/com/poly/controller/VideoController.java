package com.poly.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poly.entity.Videos;
import com.poly.service.VideoService;
import com.poly.service.impl.VideoServiceImpl;

/**
 * Servlet implementation class VideoController
 */
@WebServlet("/video")
public class VideoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     private VideoService videoservice=new VideoServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VideoController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		String href=request.getParameter("id");
		HttpSession session=request.getSession();
		
		switch (action) {
		case "watch": {
			dogetWatch(session,href,request,response);
			
			
		}
		default:
			
		}
	}
	protected void dogetWatch(HttpSession session,String href,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Videos video =videoservice.findByHref(href);
		request.setAttribute("video", video);
		RequestDispatcher requestDispatcher=request.getRequestDispatcher("/views/user/detailvideo.jsp");
		requestDispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
